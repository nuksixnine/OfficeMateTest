module.exports = async () => {
  process.env.username = '11375714'
  process.env.password = 'P@ssw077d'
  process.env.kgibUrl = 'https://krungsribrokercom-uat.aycap.bayad.co.th'
}
