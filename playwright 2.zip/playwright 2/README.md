# tms-ui-test
# Creted By Nantawan Chailek

1. Cd to folder .Playwright

2. Installing Playwright
https://playwright.dev/docs/intro/
    - npm i -D playwright
    - npm i -D @playwright/test  
    or
    - yarn add playwright
    - yarn add @playwright/test

3. Created config file for test environment
    - Add setup script
        - */package.json

4. How to run test
    - yarn run:sit

5. Folder Structure
    - /tests: spec files
    - /pages: reusable codes, page objects

6. Report & Library

