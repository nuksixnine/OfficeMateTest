module.exports = {
  globalSetup: 'staging.js',
  timeout: 60000,
  use: {
    ignoreHTTPSErrors: true,
    baseURL: 'https://aycapsu01ts382:9443',
    headless: true,
    launchOptions: {
      slowMo: 0,
    },
    video: 'on',
    screenshot: 'only-on-failure',
    retries: 1,
    viewport: { width: 1280, height: 720 },
  },
  projects: [
  //   // Test against mobile viewports.
  //   {
  //     name: 'Pixel5',
  //     use: devices['Pixel 5'],
  //   },
  //   {
  //     name: 'iPhone12',
  //     use: devices['iPhone 12'],
  //   },
     {
      name: 'Chromium',
      use: {
        browserName: 'chromium',
        viewport: { width: 1280, height: 720 },
      }
    },
  ],
}
