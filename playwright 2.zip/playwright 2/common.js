// Random number
function generateRandomInteger(min, max) {
    return Math.floor(min + Math.random()*(max + 1 - min))
  }
const current_number = generateRandomInteger(1, 1000);

// Random string a-z, A-Z
function randomStringEN(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 
 charactersLength));
   }
   return result;
}
const current_characterEN = randomStringEN(5);

// Random string ก-ฮ
function randomStringTH(length) {
    var result           = '';
    var characters       = 'กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรลวศษสหฬอฮ';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * 
 charactersLength));
   }
   return result;
}
const promotionName = {
    randomStringTH: randomStringTH,
    randomStringEN: randomStringEN,
    generateRandomInteger: generateRandomInteger
}

module.exports = promotionName;