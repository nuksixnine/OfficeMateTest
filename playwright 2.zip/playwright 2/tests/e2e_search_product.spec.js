const { test, expect } = require('@playwright/test') 
const promotionName = require('../common')

test('Searching Post-it Note#POP UP NOTE', async ({ page }) => {
	await page.on('requestfinished', async request => {
		const resourceType = request.resourceType()
		switch (resourceType) {
			case 'document':
			case 'xhr':
			case 'fetch':
				const url = request.url()
				if (!/clarity.ms/.test(url)) {
					const response = await request.response()
					const status = response.status()
					console.log(`\t${resourceType} ${request.method()} ${url} ${status}`)
					if (
						status !== 500 &&
						status !== 404 &&
						status >= 400 &&
						response.headers()['content-type'].includes('application/json')
					) {
						console.log(request.postData())
						console.log(await response.json())
					}
				}
				break
		}
	})

    // Search 
	await page.goto(process.env.kgibUrl, { timeout: 8000 });
	await page.locator('//div[1]/div[1]/input').click();
    await page.fill('//div[1]/div[1]/input', process.env.search);
    await page.locator('//*[@id="btn-searchResultPage"]').click();

	// Check search result in the list
	await page.locator('//*[@id="lbl-ProductPreview-Name-MKP0344460"]');
	const product1 = await page.textContent('//*[@id="lbl-ProductPreview-Name-MKP0344460"]');
	const product2 = process.env.search;
	expect(product1).toEqual(product2);
	expect(product1 === product2).toBeTruthy();
	console.log('Actual product name: ' + product1);
	console.log('Expected product name: ' + product2);

	await page.locator('//div[1]/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/div');
	const price1 = await page.textContent('//div[1]/div/div/div[1]/div[3]/div[2]/div[2]/div[1]/div[1]/div');
	const price2 = process.env.price;
	expect(price1).toEqual(price2);
	expect(price1 === price2).toBeTruthy();
	console.log('Actual price ' + price1);
	console.log('Expected price ' + price2);
})