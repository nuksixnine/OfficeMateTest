const { devices } = require('@playwright/test');

module.exports = {
  globalSetup: 'development.js',
  timeout: 60000,
  use: {
    ignoreHTTPSErrors: true,
    baseURL: 'https://www.officemate.co.th/en',
    headless: false,
    launchOptions: {
      slowMo: 0,
    },
    video: 'on',
    screenshot: 'only-on-failure',
    retries: 1,
    viewport: { width: 1512, height: 982 },
  },
  // projects: [
  //   // Test against mobile viewports.
  //   {
  //     name: 'Pixel5',
  //     use: devices['Pixel 5'],
  //   },
  //   {
  //     name: 'iPhone12',
  //     use: devices['iPhone 12'],
  //   },
  //   {
  //     name: 'Chromium',
  //     use: {
  //       browserName: 'chromium',
  //       viewport: { width: 1280, height: 720 },
  //     }
  //   },
  // ],
}
