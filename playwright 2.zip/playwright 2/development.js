module.exports = async () => {
  process.env.search = 'Post-it Note#POP UP NOTE'
  process.env.password = 'admincms2'
  process.env.kgibUrl = 'https://www.officemate.co.th/en'
  process.env.price = ' ฿ 42.00'
}
